using System;
using System.Collections.Generic;

public class Itens{
  
  public String NomeIt;
  public String DescriIt;
  public Int32 Codigo;
  public Int32 PrecoIt;

}